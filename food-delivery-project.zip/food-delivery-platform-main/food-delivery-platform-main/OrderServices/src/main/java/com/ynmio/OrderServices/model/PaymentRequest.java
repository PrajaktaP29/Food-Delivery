package com.ynmio.OrderServices.model;

import lombok.Data;

@Data
public class PaymentRequest {
    private double amount;
}

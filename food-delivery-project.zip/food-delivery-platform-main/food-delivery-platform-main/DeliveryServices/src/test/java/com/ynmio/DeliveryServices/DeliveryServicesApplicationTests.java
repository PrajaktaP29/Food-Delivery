package com.ynmio.DeliveryServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}

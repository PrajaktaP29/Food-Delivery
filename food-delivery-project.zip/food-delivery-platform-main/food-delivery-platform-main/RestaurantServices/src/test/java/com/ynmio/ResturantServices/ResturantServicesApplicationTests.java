package com.ynmio.ResturantServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResturantServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}

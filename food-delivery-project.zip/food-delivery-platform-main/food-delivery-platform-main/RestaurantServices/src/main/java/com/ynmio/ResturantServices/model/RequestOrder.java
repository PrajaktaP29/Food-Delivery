package com.ynmio.ResturantServices.model;

import lombok.Data;

@Data
public class RequestOrder {

}
